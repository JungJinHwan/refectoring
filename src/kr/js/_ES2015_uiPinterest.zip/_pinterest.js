import Config from './_config';

class main extends Config {

	shift (arg) {

		const SCOPE = this;

		let Data = SCOPE.option.data;
		let Status = SCOPE.option.status;
		let Selector = SCOPE.option.selector;

		let button = SCOPE.select(Selector.story_shifter);
		let items = SCOPE.select(Selector.item);

		let index = SCOPE.index(button, arg);

		Status.touchDir = index < Status.index ? 'prev' : 'next';

		let room = Status.room[index-1];
			room = room ? room : 0;

		Status.moveLength = Status.world*Math.ceil(room)/100*-1;

		let $items = $(items.length ? items[Status.row] : items);

		let sumCount = Data.response[index].count;

		for (let i=0; i<index; i++) {

			sumCount += Data.response[i].count;
		}

		let reloader = 0;
		let idle = 0;
		function reloaderCheckItems() {

			let newItems = SCOPE.select(Selector.item);

			if (newItems.length < sumCount) {
				
				SCOPE.move({ idx: index });

				idle++;

				if (idle > 10) {

					// 아무것도 안하고 있는 상태가 10이상 반복되면
					// 이런식으로 처리하면 안되는데 ㅠ.ㅠ
					return window.cancelAnimationFrame(reloader);
				}

				return window.requestAnimationFrame(reloaderCheckItems);
			}

			SCOPE.move({ idx: index });

			return window.cancelAnimationFrame(reloader);
		}

		reloader = window.requestAnimationFrame(reloaderCheckItems);

		return SCOPE;
	}

	move (arg) {

		const SCOPE = this;

		let Data = SCOPE.option.data;
		let Status = SCOPE.option.status;
		let Selector = SCOPE.option.selector;

		let body = SCOPE.select(Selector.body);
		let items = SCOPE.select(Status.completeGroup[SCOPE.option.page]+'\u0020'+Selector.item);

		let bar = SCOPE.select(Selector.story_bar);

		// 내용이 위로 올라갈 때 음수가 양수가 되는것이 생각하기 편하다
		let pos = Status.moveLength*-1;

		Status.barPos = pos/Status.world*100;

		bar.style.height = Status.barPos + '%';

		body.style.transform = 'translateY(' + Status.moveLength + 'px)';

		let shield = true;

		if (Status.moveLength*-1 < 0 ) {
			if (shield) {

				setTimeout(() => {

					shield = true;

					Status.moveLength = 0;

					body.style.transform = 'translateY(0px)';

				}, 150);
			}

			shield = false;
		}

		let bodyHeight = SCOPE.select('body').clientHeight;

		if (arg) {

			Status.index = arg.idx;

			SCOPE.pull();

		} else {

			let roomLimit = Status.room[Status.touchDir == 'prev' ? Status.index-1 : Status.index];

			Status.prev = roomLimit >= Status.barPos;
			Status.next = roomLimit <= Status.barPos;

			if (Status.touchDir === 'prev') {

				if (Status.prev) {

					if (Status.index > 0) {

						Status.index--;

						SCOPE.pull();
					}
				}
			}

			if (Status.touchDir === 'next') {

				if (Status.next) {

					if (Status.index < Data.resLen-1) {

						Status.index++;

						SCOPE.pull();
					}
				}
			}
		}

		let $items = $(items.length ? items[Status.row] : items);

		Status.nextLimit = bodyHeight - $items.height();

		if (Status.nextLimit >= $items.offset().top) {

			SCOPE.next();
		}

		return this;
	}

	pull (arg) {
		
		const SCOPE = this;

		let Status = SCOPE.option.status;
		let Selector = SCOPE.option.selector;

		let monthGroup = SCOPE.select(Selector.story_shift);

		for (let i=0; i<monthGroup.length; i++) {

			monthGroup[i].setAttribute('class', 'of');
		}

		monthGroup[Status.index].setAttribute('class', 'ov');

		return this;
	}

	lithener () {
		// 다음 페이지를 가져올 때 이벤트를 다시 연결해야 하는 경우가 있기 때문에 기존 연결된 이벤트를 일단 삭제, 닥치고 삭제, 아 몰랑
		$DOCUMENT.off('.def').off('.touch').off('.wheel');

		const SCOPE = this;

		let Selector = SCOPE.option.selector;
		let Process = SCOPE.option.process;
		let Status = SCOPE.option.status;
		let Event = SCOPE.option.event;
		let Data = SCOPE.option.data;

		Status.touchDir = '';

	    Process.dir = delta => {
	        // 휠 방향 [ 1:위, -1:아래 ]
	        return (delta < 0) ? delta = 1 : delta = -1;
	    }

	    // 클릭 up
		$DOCUMENT.on(
			Event.def, Selector.pin_up, function(event) {
				event.preventDefault();

				if (Status.render && Status.ani && Status.append) {

					Status.barPos = 100;

					SCOPE.option.page = Data.resLen-1;

					// 다음 json 데이터 요청 메서드 여기서 실행
					/* 데이터 리딩 방향 */ Status.touchDir = 'prev';
					/* function */ SCOPE.next();
				}
			}
		);

	    // 클릭 down
		$DOCUMENT.on(
			Event.def, Selector.pin_down, function(event) {
				event.preventDefault();

				if (Status.render && Status.ani && Status.append) {

					Status.barPos = 100;

					SCOPE.option.page = Data.resLen-1;

					// 다음 json 데이터 요청 메서드 여기서 실행
					/* 데이터 리딩 방향 */ Status.touchDir = 'next';
					/* function */ SCOPE.next();
				}
			}
		);

	    // 클릭 top
		$DOCUMENT.on(
			Event.def, Selector.pin_top, function(event) {
				event.preventDefault();

				if (Status.render && Status.ani && Status.append) {

					Status.barPos = 100;

					SCOPE.option.page = Data.resLen-1;

					// 다음 json 데이터 요청 메서드 여기서 실행
					/* 요쳥 url 변경 */ Status.touchDir = 'first';
					/* function */ SCOPE.next();
				}
			}
		);

		// 마우스 휠
	    $DOCUMENT.on(
	    	Event.wheel, Selector.scroll, function(event) {
	    		event.preventDefault();

	    		if (Status.render && Status.ani && Status.append) {

			        let saveDir = null;

			        if(event.originalEvent.wheelDelta != undefined) {

			        	let delta = event.originalEvent.wheelDelta;

			            saveDir = Process.dir(event.originalEvent.wheelDelta*-1); // IE, CROME, SFARI
			        	// console.log('IE, CROME, SFARI', event.originalEvent.wheelDelta);

			            if ((delta < 0 ? delta*-1 : delta ) < 240) {

							Status.moveLength += event.originalEvent.wheelDelta/1.5;
			            }

			            Status.vender = 0;

			        }else{

			            saveDir = Process.dir(event.originalEvent.detail); // FF
			            //console.log('FF', event.originalEvent.detail);

			            Status.vender = 1;
			        }

			        Status.touchDir = saveDir > 0 ? 'prev' : 'next';

					if (Status.vender) {

						if (Status.touchDir === 'prev') {

							Status.moveLength += 100;
						}

						if (Status.touchDir === 'next') {

							Status.moveLength -= 100;
						}
					}

			   		SCOPE.move();
		    	}
	    	}
	    );

	    return this;
	}

	resizebled () {

		const SCOPE = this;

		let Status = SCOPE.option.status;

		Status.resizebled = false;

		return this;
	}

	resize (callback) {

		const SCOPE = this;

		let Status = SCOPE.option.status;
		let Selector = SCOPE.option.selector;

		let items = SCOPE.select(Selector.item);
		let itemsLen = items.length;

		for (let i=0; i<itemsLen; i++) {
			items[i].style.transitionProperty = 'top, left';
		}

		Status.resizebled = true;

		return SCOPE.returnCall(callback);
	}

	transform (arg, callback, _this) {

		const SCOPE = this;

		let Selector = SCOPE.option.selector;
		let Status = SCOPE.option.status;

		if (Status.ani) {

			if (arg != null) {

				let attrStringArray = [ 'ver_1', 'ver_2' ];

				if (SCOPE.hasAttr(Selector.parent, 'class', attrStringArray[arg])) {

					return null;
				}
			}

			let button = SCOPE.select(Selector.button_wrap);
			let index = SCOPE.index(button, _this);

			for (let i=0; i<button.length; i++) {

				if (index == i) {

					continue;
				}

				button[i].setAttribute('class', String(button[i].classList).replace(/[\s]+(on)/g,''));
			}

			_this.setAttribute('class', String(_this.classList)+'\u0020on');

			Status.ani = false;

			let parent = SCOPE.select(Selector.parent);

			parent.style.transitionProperty = 'transform, opacity';
			parent.style.transitionDuration = '300ms';
			parent.style.opacity = 0;

			let items = SCOPE.select(Selector.item);
			let itemsLen = items.length;

			for (let i=0; i<itemsLen; i++) {
				items[i].style.transitionProperty = 'transform, opacity';
				items[i].style.transform = 'translateY(-100px)';
				items[i].style.transitionDelay = '0ms';
				items[i].style.opacity = 0;
			}

			setTimeout(() => {

				if(arg == 0) {

					parent.setAttribute('class', 'grid ver_1');
				}

				if(arg == 1) {

					parent.setAttribute('class', 'grid ver_2');
				}

			}, 400);

			setTimeout(() => {

				parent.style.opacity = 1;

				Status.transform = true;

				SCOPE.returnCall(callback);

				Status.ani = true;

			}, 600);
		}

		return this;
	}

	next (arg) {
		// 이 메서드는 위치 계산 완료 후, 혹은 정렬 애니메이션 완료 후에 호출
		// *완료 후 상태를 판단하고 처리한다

		const SCOPE = this;

		let Data = SCOPE.option.data;
		let Status = SCOPE.option.status;
		let Selector = SCOPE.option.selector;

		if(Status.barPos >= 100) {

			// 헌것을 비우고
			Status.barPos = Status.nextLimit = Status.index = Status.prev = Status.next = Status.ani = null;

			// 새것을 채운다
			Status.barPos = 0;
			Status.nextLimit = 0;
			Status.index = 0;
			Status.row = 0;
			Status.prev = false;
			Status.next = false;
			Status.append = false;
			Status.ani = false;
			Status.moveLength = 0;

			//  시각요소 초기화
			let bar = SCOPE.select(Selector.story_bar);
			let month = SCOPE.select(Selector.story_month);
			let body = SCOPE.select(Selector.body);

			bar.style.top = '100px';
			bar.style.opacity = '0';
			bar.style.transitionDuration = '1000ms';
			bar.style.transitionTimingFunction = 'ease-in-out';

			month.style.top = '100px';
			month.style.opacity = 0;
			month.style.transitionProperty = 'opacity, top';
			month.style.transitionDuration = '300ms';

			body.style.opacity = 0;
			body.style.transitionProperty = 'opacity';

			// 트라이던트 체크
			body.style.transitionDuration = Status.trident ? '0ms' : '300ms';

			setTimeout(() => {

				bar.setAttribute('style', '');

				SCOPE.option.page = 0;
				SCOPE.option.count = 0;

				// 새것은 새그릇에
				Data.response = null;
				Data.completeStory = null;
				Data.completeList = null;

				month.innerHTML = '';
				month.style.top = 0;
				month.style.opacity = 1;

				body.innerHTML = '';
				body.style.transform = 'translateY('+Status.moveLength+'px)';
				body.style.opacity = 1;
				body.style.transitionProperty = 'opacity';

				Status.complete = [];
				Status.completeGroup = [];

				// 다음 json 데이터 요청 메서드 여기서 실행
				/* function */ SCOPE.render(SCOPE.option.renderList);

			}, 700);
		}
		else {

			if (SCOPE.option.count < Data.response[SCOPE.option.page].count) {

				Status.append = false;
				Status.ani = false;

				// 추가한 list 갯수가 모자랄 때 남은 목록 limit 만큼 또 추가
				/* function */ SCOPE.returnCall([ 'bind', 'append' ]);
			}
			else {

				// 현제 추가된 된 list 갯수가, 요청된 page 의 list 갯수와 일치하면 다음 그룹으로 넘어가고
				// 현재 진행중인 page 카운트가 작으면, 만족할 때까지 증가
				// 이것은 다음달 리스트를 불러오기 위한 판단기준이 된다

				if( SCOPE.option.page < Data.resLen-1){

					Status.append = false;
					Status.ani = false;

					SCOPE.option.page++;

					// 다음달 리스트 가져오기 전 초기화
					SCOPE.option.count = 0;

					// 다음달 리스트 가져오는 메서드 여기서 실행
					/* function */ SCOPE.returnCall([ 'bind', 'append' ]);
				}
			}
		}

		return this;
	}

	ani (arg) {

		const SCOPE = this;

		let Status = SCOPE.option.status;
		let Selector = SCOPE.option.selector;

		let group = Status.completeGroup;
		let groupLen = group.length;

		for (let i=0; i<groupLen; i++) {

			let $items = $(group[i]+'\u0020'+Selector.item);
			let $itemsLen = $items.length;

			for (let j=0; j<$itemsLen; j++) {

				var aniTime = 30*(j+1);

				$items[j].style.transform = 'translateY(0)';
				$items[j].style.opacity = '1';
				$items[j].style.transitionDelay = aniTime+'ms';
				$items[j].style.transitionDuration = '300ms';
				$items[j].style.transitionProperty = 'transform, opacity';
			}
		}

		// count 저장
		SCOPE.option.count = $(group[SCOPE.option.page]+'\u0020'+Selector.item).length;

		let timeout = null;

		timeout = setTimeout(() => {

			Status.ani = true;
		}, aniTime);

		return this;
	}

	sort (arg) {

		const SCOPE = this;

		let Data = SCOPE.option.data;
		let Status = SCOPE.option.status;
		let Selector = SCOPE.option.selector;

		for (let i=0; i<Status.completeGroup.length; i++) {

			if (Status.transform || Status.resizebled || i === SCOPE.option.page) {

				let $items = $(Status.completeGroup[i]+'\u0020'+Selector.item);
				let $itemsLen = $items.length;

				let parent = SCOPE.select(Selector.parent);
				let body = SCOPE.select(Selector.body);

				var grid = [[]]; // grid[0][0] = x , grid[1][0] = y : (y는 동적 생성)

				let cnt = { w: 0, h: 0, n: 0, y: 0 };

				let map = {
					iwidth: $items[0].offsetWidth,
					iworld: body.clientWidth
				};

				// 너비 한계선
				for(let j=0; j<$itemsLen; j++){

					// 너비 한계치에 도달하면
					if(map.iwidth*(cnt.w+1) > map.iworld){

						cnt.h++; // 높이 단계 값 증가

						grid[cnt.h] = []; // 높이 단계 증가시 배열 추가

						// 한계치 도달점을 기준으로 현재까지의 각 목록의 높이를 여백을 포함하여 배열 저장
						for(let k=cnt.n; k<cnt.n+cnt.w; k++){

							cnt.i = $items[k].offsetHeight;

							grid[cnt.h][cnt.y] = (cnt.h > 1) ? cnt.i + grid[cnt.h-1][cnt.y] : cnt.i;

							cnt.y++;
						}

						cnt.n += cnt.w;
						cnt.y = 0;
						cnt.w = 0; // 너비 한계값 초기화
					}

					grid[0][cnt.w] = map.iwidth * (cnt.w); // x 좌표

					$items[j].style.top = ((cnt.h > 0 ? grid[cnt.h][cnt.w] : 0)) + 'px';
					$items[j].style.left = grid[0][cnt.w] + 'px';


					cnt.w++;
				}

				Status.row = $itemsLen-grid[0].length;

				let countAll = 0;
				let count = [];

				// 저장된 데이터의 총 카운터를 구해 전체를 구하고, 각 그룹의 리스트 카운터로 각 그룹의 전체를 구한다.
				// 일부/전체*100 의 공식으로 전체에 대한 일부의 퍼센테이지를 구한다.

				for (let i=0; i<Data.resLen; i++) {

					countAll += Data.response[i].count;
					count[i] = Data.response[i].count;
				}

				Status.world = 0;
				Status.roomWorld = [];
				Status.room = [];

				let monthGroup = SCOPE.select(Selector.story_month).children;

				for (let i=0; i<monthGroup.length; i++) {

					let room = count[i]/countAll*100;

					Status.room[i] = i ? Status.room[i-1] + room : room;
					Status.roomWorld[i] = Math.ceil(count[i]/grid[0].length)*$items[0].offsetHeight;

					Status.world += Status.roomWorld[i];

					monthGroup[i].style.height = room + '%';
				}

				// 전체 행 갯수 * 아이템 하나의 높이 = 전체 높이, 모든 카드의 크키가 같으면 편하지 ^_^♡
				parent.style.height = Status.world + 'px';

				SCOPE.select(Status.completeGroup[i]).style.height = Status.roomWorld[i] + 'px';
			}
			else{
				continue;
			}
		}

		grid = null;

		return this;
	}

	bind (arg) {

		const SCOPE = this;

		let Data = SCOPE.option.data;
		let Status = SCOPE.option.status;
		let Selector = SCOPE.option.selector;

		// SCOPE.option.count 만큼 처리할 배열에서 제외하고 복사
		// slice는 깊은 복사이기 때문에 원본은 유지된다
		let list = Data.response[SCOPE.option.page].list.slice(SCOPE.option.count);
		let listLen = list.length < SCOPE.option.limit ? list.length : SCOPE.option.limit;

		// 매번 주소가 다른 객체를 벹어줘야 한다
		let Str = SCOPE.storage();
		let _Str = SCOPE._storage({ list: [] });

		let i = 0;

		Data.completeStory = '';
		Data.completeList = '';

		(function keyBind(_val){

			_Str.list[i] = Str.list;

			for(let key in list[i]) {

				if (key == 'category') {
					// list.category 지정
					list[i].category = 'category__'+list[i].category;
				}

				if (key == 'img') {
					// list.img 비어 있으면 default
					if (!list[i].img.length) {
						
						list[i].img = SCOPE.option.no_img;
					}
				}

				if (key == 'photo') {
					// list.photo 비어 있으면 default
					if (!list[i].photo.length) {

						list[i].photo = list[i].category == 'category__'+2 ? SCOPE.option.no_instagram : SCOPE.option.no_photo;
					}
				}

				if (key == 'name') {
					// list.name 비어 있으면 default
					if (!list[i].name.length) {
						
						list[i].name = SCOPE.option.no_name;
					}
				}

				if (key == 'date') {
					// list.date 가공
					let date = Data.dateList[SCOPE.option.page];

					list[i].date = SCOPE.option.month_string[Number(date.m)-1]+'\u0020'+date.d+',\u0020'+date.y;
				}

				_Str.list[i] = _Str.list[i].replace( SCOPE.reg(key), list[i][key] );

				_val++;
			}

			Data.completeList += _Str.list[i];

			i++;

			if (i < listLen) {

				return keyBind(0);
			} 
			else {

				Data.completeMonth = (() => {

					if (SCOPE.option.page > 0) {
						return '';
					}

					let _Str = SCOPE._storage({ month: '' });

					for (let i=0; i<Data.resLen; i++) {

						let date = Data.dateList[i];

						_Str.month += Str.month({ y: date.y, m: date.m, idx: i });
					}

					return _Str.month;
				})();

				let dateList = Data.dateList[SCOPE.option.page];

				// 생성된 그룹 셀렉터 저장	
				if (Status.completeGroup.length-1 != SCOPE.option.page) {
					Selector.completeGroup = '#group'+(dateList.y + dateList.m);
					Status.completeGroup[SCOPE.option.page] = Selector.completeGroup;

				}

				// 생성된 버튼 셀렉터 저장
				if (Status.complete.length-1 != SCOPE.option.page) {
					Selector.completeMonth = '#month'+(dateList.y + dateList.m);
					Status.complete[SCOPE.option.page] = Selector.completeMonth;

				}
			}

			return 1;
		})(0);


		return SCOPE;
	}

	append (arg) {

		const SCOPE = this;

		let Data = SCOPE.option.data;
		let Status = SCOPE.option.status;
		let Selector = SCOPE.option.selector;

		let select = '';
		let completeBind = '';

		// 현재 처리완료 된 리스트가 전체 리스트 보다 아직 작을 때, 대상 그룹이 존재하면 그 그룹 안으로 남은 리시트를 추가
		if (SCOPE.select(Selector.completeGroup) && SCOPE.option.count < Data.response[SCOPE.option.page].count) {
			select = Selector.completeGroup;
			completeBind = Data.completeList;

		}
		// 현재 리스트 처리가 완료 됬을때 다음 페이지 리스트를 새 그룹으로 묶어서 보낸다
		else{
			select = Selector.body;
			completeBind = '\n<div class="group" id="'+Selector.completeGroup.substr(1)+'">'+Data.completeList+'\n</div>';

			// 추가된 다음달 추가
			SCOPE.select(Selector.story_month).innerHTML += Data.completeMonth;
		}

		// 처리된 상태 HTML 에 반영
		SCOPE.select(select).innerHTML += completeBind;

		Status.append = true;
		Status.render = true;

		let body = SCOPE.select(Selector.body);

		body.style.transitionProperty = 'transform';

		// 트라이던트 체크
		body.style.transitionDuration = Status.trident ? '0ms' : '300ms';

		// 재귀 종료 지점 콜백 리스트 실행
		SCOPE.returnCall(SCOPE.option.completeFunctionList);


		return SCOPE;
	}

	render (callback) {

		const SCOPE = this;

		let Status = SCOPE.option.status;
		let Reuqest = SCOPE.option.request;

		Status.render = false;

		if (Reuqest.data.page < 1) {
			Status.touchDir = 'first';
		}

		switch (Status.touchDir) {
			case 'prev':
				Reuqest.data.page--;
					break;

			case 'next':
				Reuqest.data.page++;
					break;

			case 'first':
				Reuqest.data.page = 1;
					break;
		}

		Status.touchDir = '';

		return SCOPE.request(res => {

			if (res.length) {

				SCOPE.option.data.response = res;
				SCOPE.option.data.resLen = res.length;

				// 날짜 저장
				SCOPE.option.data.dateList = [];

				for (let i=0; i<SCOPE.option.data.resLen; i++) {

					let date = SCOPE.option.data.response[i].list[0].date.split('-');

					SCOPE.option.data.dateList[i] = { y: date[0], m: date[1], d: date[2] };
				}

				return SCOPE.returnCall(callback);
			}
			else{

				SCOPE.select(SCOPE.option.selector.body).innerHTML = SCOPE.storage().isEmpty;

				return SCOPE.returnCall([ 'returnBar' ]);
			}
		});
	}

	returnBar (arg) {

		const SCOPE = this;

		let Selector = SCOPE.option.selector;
		let reBar = SCOPE.select(Selector.returnBar);

		let start = null;
		let barFrame = 0;

		function step(timestamp) {

			if (!start) start = timestamp;

			let progress = timestamp - start;

			reBar.style.width = Math.min(progress / 10, reBar.parentNode.clientWidth) + 'px';

			if (parseInt(reBar.style.width) < reBar.parentNode.clientWidth) {

				return window.requestAnimationFrame(step);
			}
			else {

				window.cancelAnimationFrame(barFrame);

				$('#isEmpty').fadeOut(300, () => {

					SCOPE.option.request.data.page = 1;

					SCOPE.render(SCOPE.option.renderList);
				});

				return SCOPE;
			}
		}

		barFrame = window.requestAnimationFrame(step);

		$DOCUMENT.off('.return').on(
			'click.return', Selector.returnButton, function (event) {
				event.preventDefault();

				window.cancelAnimationFrame(barFrame);

				$('#isEmpty').fadeOut(300, () => {

					SCOPE.option.request.data.page = 1;

					SCOPE.render(SCOPE.option.renderList);
				});
			}
		);
	}
}

window.$UI_PINTEREST = new main({/* user only => _config.js */});